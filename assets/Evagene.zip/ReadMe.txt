Evagene Clinical Release Notes

Thank you for using Evagene Clinical. At Xiasma, we have worked hard 
to create an innovative tool to help genetic counsellors, nurses, 
researchers and other professionals to draw, manage, analyse and report 
pedigree data and we appreciate the investment in time that you are making 
to assist us improve our software by reporting any problems and requesting 
features in forthcoming releases. Your opinions are valuable to us and 
will help shape the future of Evagene.

Software may contain bugs, defects and errors and should not be expected to 
always function fully upon installation. We recommend that you should not 
use it to support clinicial, medical or any other decisions. We make no 
promises that data or files created or modified in this release will be 
compatible with future versions.

We shall endeavour to make available frequent updates of Evagene and ask 
that you always try to use the most up-to-date version. 
If you have any questions, ideas, recommendations or comments, please 
email them to ideas@evagene.com.

Thank you once again and enjoy your time with Evagene.

Adrian Pickering
Xiasma Ltd

http://www.evagene.com/
